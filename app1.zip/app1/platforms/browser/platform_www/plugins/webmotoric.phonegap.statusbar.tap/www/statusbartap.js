cordova.define("webmotoric.phonegap.statusbar.tap.StatusbarTap", function(require, exports, module) { var exec = require('cordova/exec');
var StatusbarTap = function(){exec(null, null, 'StatusbarTap', 'initListener', []);};
module.exports = new StatusbarTap();
});
